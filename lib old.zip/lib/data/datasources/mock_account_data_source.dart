import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/account_model.dart';
import '../models/transaction_model.dart';
import '../models/admin_user_model.dart';

abstract class AccountDataSource {
  Future<void> init();
  Future<AccountModel> fetchAccountDetails(String accountId);
  Future<List<TransactionModel>> fetchTransactions(String accountId);
  Future<void> performTransfer(String senderId, String recipient, double amount, String notes);
  Future<void> payBill(String senderId, String billerId, String consumerId, double amount);
  void registerUser(String name, String email, String phone);
  
  // Admin methods
  Future<List<AdminUserModel>> fetchAllUsers();
  Future<void> blockUser(String userId);
  Future<void> unblockUser(String userId);
  Future<void> adjustBalance(String userId, double amount);
  Future<List<Map<String, dynamic>>> fetchBillers();
}

class MockAccountDataSourceImpl implements AccountDataSource {
  static const String _balanceKey = 'wallet_balance';
  static const String _transactionsKey = 'wallet_transactions';

  static double _balance = 1450.75;
  static String? _registeredName;
  static String? _registeredEmail;
  static String? _registeredPhone;
  static String? _registeredId;

  static final List<AdminUserModel> _adminUsers = [
    const AdminUserModel(id: 'acc_123', name: 'John Doe', email: 'john@example.com', phone: '+1234567890', balance: 1450.75, isBlocked: false),
    const AdminUserModel(id: 'acc_456', name: 'Alice Smith', email: 'alice@example.com', phone: '+1987654321', balance: 8500.00, isBlocked: false),
    const AdminUserModel(id: 'acc_789', name: 'Bob Johnson', email: 'bob@example.com', phone: '+1555666777', balance: 320.50, isBlocked: true),
  ];

  static List<TransactionModel> _transactions = [
    // ... same transactions
    TransactionModel(
      id: 'tx_101',
      amount: 250.0,
      date: DateTime.now().subtract(const Duration(days: 1)),
      description: 'Grocery Store',
      isCredit: false,
    ),
    TransactionModel(
      id: 'tx_102',
      amount: 1500.0,
      date: DateTime.now().subtract(const Duration(days: 3)),
      description: 'Salary Deposit',
      isCredit: true,
    ),
    TransactionModel(
      id: 'tx_103',
      amount: 50.0,
      date: DateTime.now().subtract(const Duration(days: 5)),
      description: 'Coffee Shop',
      isCredit: false,
    ),
  ];

  @override
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    
    // Load balance
    if (prefs.containsKey(_balanceKey)) {
      _balance = prefs.getDouble(_balanceKey) ?? _balance;
    }

    // Load transactions
    if (prefs.containsKey(_transactionsKey)) {
      final String? txJson = prefs.getString(_transactionsKey);
      if (txJson != null) {
        final List<dynamic> decoded = json.decode(txJson);
        _transactions = decoded.map((item) => TransactionModel.fromJson(item)).toList();
      }
    }
  }

  Future<void> _saveToDisk() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_balanceKey, _balance);
    
    final String encoded = json.encode(_transactions.map((tx) => tx.toJson()).toList());
    await prefs.setString(_transactionsKey, encoded);
  }

  @override
  Future<AccountModel> fetchAccountDetails(String accountId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    
    String name = _registeredName ?? 'John Doe';
    if (accountId == 'acc_456') name = 'Alice Smith';
    if (accountId == 'acc_789') name = 'Bob Johnson';
    
    return AccountModel(
      id: accountId,
      accountHolderName: name,
      balance: _balance,
    );
  }

  @override
  void registerUser(String name, String email, String phone) {
    _registeredName = name;
    _registeredEmail = email;
    _registeredPhone = phone;
    _registeredId = 'acc_${DateTime.now().millisecondsSinceEpoch}';
    
    // Add to admin list
    _adminUsers.add(AdminUserModel(
      id: _registeredId!, 
      name: name, 
      email: email, 
      phone: phone, 
      balance: _balance, 
      isBlocked: false
    ));
  }

  @override
  Future<List<AdminUserModel>> fetchAllUsers() async {
    await Future.delayed(const Duration(milliseconds: 500));
    return List.from(_adminUsers);
  }

  @override
  Future<void> blockUser(String userId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final index = _adminUsers.indexWhere((u) => u.id == userId);
    if (index != -1) {
      _adminUsers[index] = _adminUsers[index].copyWith(isBlocked: true);
    }
  }

  @override
  Future<void> unblockUser(String userId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final index = _adminUsers.indexWhere((u) => u.id == userId);
    if (index != -1) {
      _adminUsers[index] = _adminUsers[index].copyWith(isBlocked: false);
    }
  }

  @override
  Future<void> adjustBalance(String userId, double amount) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final index = _adminUsers.indexWhere((u) => u.id == userId);
    if (index != -1) {
      _adminUsers[index] = _adminUsers[index].copyWith(balance: _adminUsers[index].balance + amount);
      if (userId == 'acc_123' || userId == _registeredId) {
        _balance += amount; 
        await _saveToDisk();
      }
    }
  }

  @override
  Future<List<TransactionModel>> fetchTransactions(String accountId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    return List.from(_transactions.reversed);
  }

  @override
  Future<void> performTransfer(String senderId, String recipient, double amount, String notes) async {
    await Future.delayed(const Duration(seconds: 1));
    
    if (amount > _balance) {
      throw Exception('Insufficient balance');
    }

    _balance -= amount;
    _transactions.add(TransactionModel(
      id: 'tx_${DateTime.now().millisecondsSinceEpoch}',
      amount: amount,
      date: DateTime.now(),
      description: 'Transfer to $recipient',
      isCredit: false,
    ));

    await _saveToDisk();
  }

  @override
  Future<void> payBill(String senderId, String billerId, String consumerId, double amount) async {
    await Future.delayed(const Duration(seconds: 1));

    if (amount > _balance) {
      throw Exception('Insufficient balance for this payment');
    }

    _balance -= amount;
    _transactions.add(TransactionModel(
      id: 'bill_${DateTime.now().millisecondsSinceEpoch}',
      amount: amount,
      date: DateTime.now(),
      description: 'Bill Payment: $billerId (ID: $consumerId)',
      isCredit: false,
    ));

    await _saveToDisk();
  }

  @override
  Future<List<Map<String, dynamic>>> fetchBillers() async {
    await Future.delayed(const Duration(milliseconds: 300));
    return [
      {'id': 'b1', 'name': 'City Electricity', 'category': 'Electricity', 'icon': 'bolt'},
      {'id': 'b2', 'name': 'Regional Water Corp', 'category': 'Water', 'icon': 'water_drop'},
      {'id': 'b3', 'name': 'Gas Services', 'category': 'Gas', 'icon': 'local_fire_department'},
      {'id': 'b4', 'name': 'Fiber Net', 'category': 'Internet', 'icon': 'wifi'},
      {'id': 'b5', 'name': 'Sky Cable', 'category': 'TV', 'icon': 'tv'},
      {'id': 'b6', 'name': 'Mobile Connect', 'category': 'Mobile', 'icon': 'smartphone'},
      {'id': 'b7', 'name': 'Global SIM', 'category': 'Mobile', 'icon': 'sim_card'},
    ];
  }
}
