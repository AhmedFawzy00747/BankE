import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:contr_project/Presentation/bloc/account_bloc.dart';
import 'package:contr_project/Presentation/bloc/account_event.dart';
import 'package:contr_project/Presentation/bloc/transaction_bloc.dart';
import 'package:contr_project/Presentation/bloc/transaction_event.dart';
import 'package:contr_project/Presentation/bloc/transfer_bloc.dart';
import 'package:contr_project/Presentation/bloc/auth_bloc.dart';
import 'package:contr_project/Presentation/Views/auth/splash_screen.dart';
import 'package:contr_project/data/datasources/mock_account_data_source.dart';
import 'package:contr_project/data/repositories/account_repository_impl.dart';
import 'package:contr_project/domain/usecases/get_balance.dart';
import 'package:contr_project/domain/usecases/get_transactions.dart';
import 'package:contr_project/domain/usecases/perform_transfer.dart';
import 'package:contr_project/domain/usecases/pay_bill.dart';
import 'package:contr_project/domain/usecases/get_billers.dart';
import 'package:contr_project/core/theme/app_theme.dart';
import 'package:contr_project/core/constants/app_constants.dart';
import 'package:contr_project/domain/repositories/otp_repository.dart';
import 'package:contr_project/data/repositories/mock_otp_repository_impl.dart';
import 'package:contr_project/Presentation/bloc/otp/otp_bloc.dart';
import 'package:contr_project/Presentation/bloc/admin/admin_bloc.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  final dataSource = MockAccountDataSourceImpl();
  await dataSource.init();
  
  final accountRepository = AccountRepositoryImpl(dataSource: dataSource);
  final otpRepository = MockOtpRepositoryImpl();

  runApp(MyApp(
    accountRepository: accountRepository, 
    otpRepository: otpRepository,
    dataSource: dataSource,
  ));
}

class MyApp extends StatelessWidget {
  final AccountRepositoryImpl accountRepository;
  final OtpRepository otpRepository;
  final MockAccountDataSourceImpl dataSource;

  const MyApp({
    super.key, 
    required this.accountRepository, 
    required this.otpRepository,
    required this.dataSource,
  });

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) => AccountBloc(
            getBalanceUseCase: GetBalanceUseCase(accountRepository),
          )..add(const FetchAccountBalance(AppConstants.currentAccountId)),
        ),
        BlocProvider(
          create: (context) => TransactionBloc(
            getTransactionsUseCase: GetTransactionsUseCase(accountRepository),
          )..add(const FetchTransactions(AppConstants.currentAccountId)),
        ),
        BlocProvider(
          create: (context) => TransferBloc(
            performTransferUseCase: PerformTransferUseCase(accountRepository),
            payBillUseCase: PayBillUseCase(accountRepository),
            getBillersUseCase: GetBillersUseCase(accountRepository),
            transactionBloc: context.read<TransactionBloc>(),
            accountBloc: context.read<AccountBloc>(),
          ),
        ),
        BlocProvider(
          create: (context) => AuthBloc(dataSource: dataSource),
        ),
        BlocProvider(
          create: (context) => OtpBloc(otpRepository: otpRepository),
        ),
        BlocProvider(
          create: (context) => AdminBloc(dataSource: dataSource),
        ),
      ],
      child: MaterialApp(
        title: 'Internet Banking',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.system,
        home: const SplashScreen(),
      ),
    );
  }
}
