import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../bloc/transaction_bloc.dart';
import '../../bloc/transaction_state.dart';
import '../../widgets/analytics_helper.dart';
import '../../widgets/error_view.dart';
import '../../widgets/loading_view.dart';

class AnalyticsScreen extends StatelessWidget {
  const AnalyticsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).primaryColor;

    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text('Spending Insights', style: TextStyle(color: Theme.of(context).textTheme.titleLarge?.color, fontSize: 18, fontWeight: FontWeight.bold)),
        iconTheme: IconThemeData(color: Theme.of(context).textTheme.titleLarge?.color),
        centerTitle: true,
      ),
      body: BlocBuilder<TransactionBloc, TransactionState>(
        builder: (context, state) {
          if (state is TransactionLoading) {
            return const AppLoadingView();
          } else if (state is TransactionLoaded) {
            final transactions = state.transactions;
            final categoryTotals = AnalyticsHelper.getExpensesByCategory(transactions);
            final totalIncome = AnalyticsHelper.getTotalIncome(transactions);
            final totalExpenses = AnalyticsHelper.getTotalExpenses(transactions);

            return SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 12),
                  _buildSummaryCards(context, totalIncome, totalExpenses),
                  const SizedBox(height: 32),
                  Text(
                    'Spending Breakdown', 
                    style: TextStyle(
                      fontSize: 18, 
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).textTheme.titleLarge?.color
                    )
                  ),
                  const SizedBox(height: 24),
                  _buildPieChart(categoryTotals),
                  const SizedBox(height: 32),
                  _buildLegend(context, categoryTotals),
                  const SizedBox(height: 40),
                ],
              ),
            );
          } else if (state is TransactionError) {
            return AppErrorView(message: state.message);
          }
          return const SizedBox.shrink();
        },
      ),
    );
  }

  Widget _buildSummaryCards(BuildContext context, double income, double expenses) {
    return Row(
      children: [
        Expanded(
          child: _summaryCard(context, 'Income', income, Colors.green, Icons.arrow_downward),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: _summaryCard(context, 'Expenses', expenses, Colors.redAccent, Icons.arrow_upward),
        ),
      ],
    );
  }

  Widget _summaryCard(BuildContext context, String label, double amount, Color color, IconData icon) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.02), blurRadius: 10)],
        border: Border.all(color: Theme.of(context).dividerColor.withOpacity(0.05)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 4),
              Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '\$${amount.toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: 18, 
              fontWeight: FontWeight.bold, 
              color: color
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPieChart(Map<SpendingCategory, double> data) {
    final sections = data.entries.where((e) => e.value > 0).map((e) {
      return PieChartSectionData(
        value: e.value,
        title: '',
        color: Color(e.key.color),
        radius: 40,
      );
    }).toList();

    return SizedBox(
      height: 200,
      child: sections.isEmpty
          ? const Center(
              child: Text(
                'No transactions found for this period.',
                style: TextStyle(color: Colors.grey),
              ),
            )
          : PieChart(
              PieChartData(
                sectionsSpace: 4,
                centerSpaceRadius: 60,
                sections: sections,
              ),
            ),
    );
  }

  Widget _buildLegend(BuildContext context, Map<SpendingCategory, double> data) {
    final total = data.values.fold(0.0, (a, b) => a + b);
    
    return Column(
      children: data.entries.where((e) => e.value > 0).map((e) {
        final percentage = (e.value / total * 100).toStringAsFixed(1);
        return Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Row(
            children: [
              Container(
                width: 12, 
                height: 12, 
                decoration: BoxDecoration(color: Color(e.key.color), shape: BoxShape.circle)
              ),
              const SizedBox(width: 12),
              Text(
                e.key.name, 
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: Theme.of(context).textTheme.bodyLarge?.color
                )
              ),
              const Spacer(),
              Text(
                '\$${e.value.toStringAsFixed(2)}', 
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).textTheme.bodyLarge?.color
                )
              ),
              const SizedBox(width: 12),
              Text('$percentage%', style: const TextStyle(color: Colors.grey, fontSize: 12)),
            ],
          ),
        );
      }).toList(),
    );
  }
}
