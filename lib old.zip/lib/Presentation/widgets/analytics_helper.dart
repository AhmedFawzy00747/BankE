import '../../domain/entities/transaction.dart';

enum SpendingCategory {
  utilities(name: 'Utilities', color: 0xffFF6B6B),
  food(name: 'Food & Dining', color: 0xff4D96FF),
  transfers(name: 'Transfers', color: 0xff6BCB77),
  shopping(name: 'Shopping', color: 0xffFFD93D),
  misc(name: 'Miscellaneous', color: 0xffA2A2A2);

  final String name;
  final int color;
  const SpendingCategory({required this.name, required this.color});
}

class AnalyticsHelper {
  static Map<SpendingCategory, double> getExpensesByCategory(List<TransactionEntity> transactions) {
    Map<SpendingCategory, double> totals = {
      for (var cat in SpendingCategory.values) cat: 0.0
    };

    final expenses = transactions.where((tx) => !tx.isCredit);

    for (var tx in expenses) {
      final category = _categorize(tx.description);
      totals[category] = (totals[category] ?? 0.0) + tx.amount;
    }

    return totals;
  }

  static double getTotalIncome(List<TransactionEntity> transactions) {
    return transactions
        .where((tx) => tx.isCredit)
        .fold(0.0, (sum, tx) => sum + tx.amount);
  }

  static double getTotalExpenses(List<TransactionEntity> transactions) {
    return transactions
        .where((tx) => !tx.isCredit)
        .fold(0.0, (sum, tx) => sum + tx.amount);
  }

  static SpendingCategory _categorize(String description) {
    final desc = description.toLowerCase();
    if (desc.contains('bill') || desc.contains('electricity') || desc.contains('water') || desc.contains('gas')) {
      return SpendingCategory.utilities;
    }
    if (desc.contains('grocery') || desc.contains('coffee') || desc.contains('food') || desc.contains('restaurant')) {
      return SpendingCategory.food;
    }
    if (desc.contains('transfer')) {
      return SpendingCategory.transfers;
    }
    if (desc.contains('store') || desc.contains('shop') || desc.contains('buy') || desc.contains('market')) {
      return SpendingCategory.shopping;
    }
    return SpendingCategory.misc;
  }
}
