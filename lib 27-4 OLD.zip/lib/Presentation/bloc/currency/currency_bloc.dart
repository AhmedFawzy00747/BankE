import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

abstract class CurrencyEvent extends Equatable {
  const CurrencyEvent();
  @override
  List<Object?> get props => [];
}

class ChangeCurrencyEvent extends CurrencyEvent {
  final String currencyCode;
  const ChangeCurrencyEvent(this.currencyCode);
  @override
  List<Object?> get props => [currencyCode];
}

class CurrencyState extends Equatable {
  final String currencyCode;
  final String symbol;
  final double rateToUsd;

  const CurrencyState({
    required this.currencyCode,
    required this.symbol,
    required this.rateToUsd,
  });

  @override
  List<Object?> get props => [currencyCode, symbol, rateToUsd];

  String format(double amount) {
    return '$symbol ${(amount * rateToUsd).toStringAsFixed(2)}';
  }
}

class CurrencyBloc extends Bloc<CurrencyEvent, CurrencyState> {
  CurrencyBloc() : super(const CurrencyState(currencyCode: 'USD', symbol: '\$', rateToUsd: 1.0)) {
    on<ChangeCurrencyEvent>(_onChangeCurrency);
  }

  void _onChangeCurrency(ChangeCurrencyEvent event, Emitter<CurrencyState> emit) {
    switch (event.currencyCode) {
      case 'EUR':
        emit(const CurrencyState(currencyCode: 'EUR', symbol: '€', rateToUsd: 0.92));
        break;
      case 'GBP':
        emit(const CurrencyState(currencyCode: 'GBP', symbol: '£', rateToUsd: 0.79));
        break;
      case 'EGP':
        emit(const CurrencyState(currencyCode: 'EGP', symbol: 'EGP', rateToUsd: 48.0));
        break;
      default:
        emit(const CurrencyState(currencyCode: 'USD', symbol: '\$', rateToUsd: 1.0));
    }
  }
}
