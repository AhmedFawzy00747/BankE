import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../domain/usecases/submit_loan_request.dart';
import '../../../../domain/usecases/get_loans.dart';
import '../../../../domain/usecases/update_loan_status.dart';
import '../../../../domain/usecases/calculate_loan_emi.dart';
import 'loan_event.dart';
import 'loan_state.dart';

class LoanBloc extends Bloc<LoanEvent, LoanState> {
  final SubmitLoanRequestUseCase submitLoanRequestUseCase;
  final GetLoansUseCase getLoansUseCase;
  final UpdateLoanStatusUseCase updateLoanStatusUseCase;
  final CalculateLoanEMI calculateLoanEMI;

  LoanBloc({
    required this.submitLoanRequestUseCase,
    required this.getLoansUseCase,
    required this.updateLoanStatusUseCase,
    required this.calculateLoanEMI,
  }) : super(const LoanState()) {
    on<CalculateEMIEvent>(_onCalculateEMI);
    on<SubmitLoanRequestEvent>(_onSubmitLoan);
    on<FetchLoansEvent>(_onFetchLoans);
    on<UpdateLoanStatusEvent>(_onUpdateLoanStatus);
  }

  void _onCalculateEMI(CalculateEMIEvent event, Emitter<LoanState> emit) {
    final emi = calculateLoanEMI.execute(
      amount: event.amount,
      durationMonths: event.durationMonths,
      annualRate: event.annualRate,
    );
    emit(state.copyWith(estimatedEmi: emi));
  }

  Future<void> _onSubmitLoan(SubmitLoanRequestEvent event, Emitter<LoanState> emit) async {
    emit(state.copyWith(
      submissionStatus: LoanSubmissionStatus.submitting,
      uploadProgress: 0.0,
    ));

    try {
      // Simulate Upload Progress for production feel
      for (int i = 1; i <= 5; i++) {
        await Future.delayed(const Duration(milliseconds: 300));
        emit(state.copyWith(uploadProgress: i * 0.2));
      }

      await submitLoanRequestUseCase.execute(
        userId: event.userId,
        userName: event.userName,
        amount: event.amount,
        purpose: event.purpose,
        duration: event.durationMonths,
        pdfName: event.pdfFileName,
        pdfPath: event.pdfFilePath,
      );
      
      emit(state.copyWith(
        submissionStatus: LoanSubmissionStatus.success,
        successMessage: 'Loan request submitted successfully!',
        uploadProgress: 1.0,
      ));
      add(const FetchLoansEvent()); // Refresh after submission
    } catch (e) {
      emit(state.copyWith(
        submissionStatus: LoanSubmissionStatus.error,
        errorMessage: 'Failed to submit loan: $e',
        uploadProgress: 0.0,
      ));
    }
  }

  Future<void> _onFetchLoans(FetchLoansEvent event, Emitter<LoanState> emit) async {
    emit(state.copyWith(isLoading: true));
    try {
      final loans = await getLoansUseCase.execute();
      emit(state.copyWith(loans: loans, isLoading: false));
    } catch (e) {
      emit(state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to fetch loans: $e',
      ));
    }
  }

  Future<void> _onUpdateLoanStatus(UpdateLoanStatusEvent event, Emitter<LoanState> emit) async {
    emit(state.copyWith(isLoading: true));
    try {
      await updateLoanStatusUseCase.execute(event.loanId, event.status);
      add(const FetchLoansEvent()); // Refresh list
    } catch (e) {
      emit(state.copyWith(
        isLoading: false,
        errorMessage: 'Failed to update loan: $e',
      ));
    }
  }
}
