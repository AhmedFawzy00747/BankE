import 'package:equatable/equatable.dart';
import '../../../../domain/entities/loan_entity.dart';

enum LoanSubmissionStatus { initial, submitting, success, error }

class LoanState extends Equatable {
  final double estimatedEmi;
  final List<LoanEntity> loans;
  final LoanSubmissionStatus submissionStatus;
  final String? errorMessage;
  final String? successMessage;
  final bool isLoading;
  final double uploadProgress; // New field for simulated upload

  const LoanState({
    this.estimatedEmi = 0.0,
    this.loans = const [],
    this.submissionStatus = LoanSubmissionStatus.initial,
    this.errorMessage,
    this.successMessage,
    this.isLoading = false,
    this.uploadProgress = 0.0,
  });

  LoanState copyWith({
    double? estimatedEmi,
    List<LoanEntity>? loans,
    LoanSubmissionStatus? submissionStatus,
    String? errorMessage,
    String? successMessage,
    bool? isLoading,
    double? uploadProgress,
  }) {
    return LoanState(
      estimatedEmi: estimatedEmi ?? this.estimatedEmi,
      loans: loans ?? this.loans,
      submissionStatus: submissionStatus ?? this.submissionStatus,
      errorMessage: errorMessage,
      successMessage: successMessage,
      isLoading: isLoading ?? this.isLoading,
      uploadProgress: uploadProgress ?? this.uploadProgress,
    );
  }

  @override
  List<Object?> get props => [
        estimatedEmi,
        loans,
        submissionStatus,
        errorMessage,
        successMessage,
        isLoading,
        uploadProgress,
      ];
}
