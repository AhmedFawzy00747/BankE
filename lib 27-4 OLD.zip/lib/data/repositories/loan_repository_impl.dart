import '../../domain/entities/loan_entity.dart';
import '../../domain/repositories/loan_repository.dart';
import '../datasources/mock_account_data_source.dart'; // We use this for now as it holds loans

class LoanRepositoryImpl implements LoanRepository {
  final AccountDataSource dataSource;

  LoanRepositoryImpl(this.dataSource);

  @override
  Future<List<LoanEntity>> getAllLoans() async {
    return await dataSource.fetchAllLoans();
  }

  @override
  Future<List<LoanEntity>> getUserLoans(String userId) async {
    final allLoans = await dataSource.fetchAllLoans();
    return allLoans.where((loan) => loan.userId == userId).toList();
  }

  @override
  Future<void> submitLoanRequest({
    required String userId,
    required String userName,
    required double amount,
    required String purpose,
    required int duration,
    required String pdfName,
    required String pdfPath,
  }) async {
    await dataSource.submitLoanRequest(
      userId,
      userName,
      amount,
      purpose,
      duration,
      pdfName,
      pdfPath,
    );
  }

  @override
  Future<void> updateLoanStatus(String loanId, LoanStatus status) async {
    await dataSource.updateLoanStatus(loanId, status);
  }
}
